
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { COLORS, SHAPES as ShapeConstant } from '../constants';

// --- TYPE DEFINITIONS ---

// General
type GameType = 'path-finder' | 'cct';

// --- Path Finder ---
type PathGameMode = 'on-path' | 'off-path' | 'dynamic';
type PathTextColorMode = 'white' | 'contrast' | 'random';
type PathItem = {
  id: number;
  x: number;
  y: number;
  colorIndex: number;
  shapeIndex: number;
  wordIndex: number;
  isOnPath: boolean;
  distanceToFinishSq: number;
};
type PathFinderGameState = 'idle' | 'memorizing' | 'responding' | 'feedback';
type PathFinderSettings = {
    mode: PathGameMode;
    vocabulary: string;
    itemCount: number;
    pathComplexity: number;
    numberOfTargets: number;
    textColor: PathTextColorMode;
    memorizationDuration: number; // in seconds
    stimuli: {
        color: boolean;
        shape: boolean;
        word: boolean;
    }
};
type PathFinderUserSelection = {
    colorIndices: Set<number>;
    wordIndices: Set<number>;
    shapeIndices: Set<number>;
};
type RoundData = {
    items: PathItem[];
    pathPoints: {x: number, y: number}[];
    finishPoint: {x: number, y: number};
    targetItems: PathItem[];
    rule: 'on-path' | 'off-path';
    targetProperties: {
        colors: Set<number>;
        shapes: Set<number>;
        words: Set<number>;
    };
};

// --- CCT ---
type CCTGameState = 'idle' | 'running' | 'finished';
type CCTPhase = 'interfering' | 'presenting' | 'responding' | 'feedback';
type CCTSettings = {
    trials: number;
    speed: number; // Base speed
    maxNumber: number;
    windowSize: number; // Numbers to sum
    visual: boolean;
    audio: boolean;
    adaptive: boolean;
    showCorrectAnswer: boolean;
    interferenceEnabled: boolean;
    interferenceChance: number;
    interferenceVocabulary: string;
};

// --- Combined Studio Settings ---
type StudioSettings = {
    pathFinder: PathFinderSettings;
    cct: CCTSettings;
}

// --- PROPS ---
interface CreatorStudioProps {
    autoSave: boolean;
}

// --- DEFAULT SETTINGS & LOADER ---
const defaultStudioSettings: StudioSettings = {
    pathFinder: {
        mode: 'dynamic',
        vocabulary: 'CAT,DOG,BIRD,FISH,TREE,STAR,SUN,MOON',
        itemCount: 15,
        pathComplexity: 4,
        numberOfTargets: 1,
        textColor: 'white',
        memorizationDuration: 5,
        stimuli: {
            color: true,
            shape: true,
            word: true,
        },
    },
    cct: {
        trials: 20,
        speed: 3000,
        maxNumber: 9,
        windowSize: 2,
        visual: true,
        audio: true,
        adaptive: true,
        showCorrectAnswer: true,
        interferenceEnabled: false,
        interferenceChance: 25,
        interferenceVocabulary: 'HEY,LOOK,PAY,ATTENTION,LISTEN,WATCH',
    }
};

const loadStudioSettings = (): StudioSettings => {
    try {
        const saved = localStorage.getItem('chunkCoreCreatorStudioSettings');
        if (saved) {
            const parsed = JSON.parse(saved);
            // Deep merge to prevent missing keys on new updates
            const loadedPathFinder = { ...defaultStudioSettings.pathFinder, ...parsed.pathFinder };
            const loadedCCT = { ...defaultStudioSettings.cct, ...parsed.cct };
            loadedPathFinder.stimuli = { ...defaultStudioSettings.pathFinder.stimuli, ...(parsed.pathFinder?.stimuli || {}) };

            return { pathFinder: loadedPathFinder, cct: loadedCCT };
        }
        return defaultStudioSettings;
    } catch (error) {
        console.error('Error loading Creator Studio settings:', error);
        return defaultStudioSettings;
    }
};

// --- PATH FINDER: HELPERS & COMPONENTS ---

const getContrastingTextColor = (hexColor: string): string => {
    if (!hexColor || hexColor.length < 7) return '#FFFFFF';
    const cleanHex = hexColor.startsWith('#') ? hexColor.slice(1) : hexColor;
    const r = parseInt(cleanHex.substring(0, 2), 16);
    const g = parseInt(cleanHex.substring(2, 4), 16);
    const b = parseInt(cleanHex.substring(4, 6), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.5 ? '#000000' : '#FFFFFF';
};

const distanceSq = (p1: {x:number, y:number}, p2: {x:number, y:number}) => (p1.x - p2.x)**2 + (p1.y - p2.y)**2;

const isPointOnPath = (point: {x: number, y: number}, pathPoints: {x: number, y: number}[], threshold: number): boolean => {
    if (pathPoints.length < 2) return false;
    const thresholdSq = threshold * threshold;
    for (let i = 0; i < pathPoints.length - 1; i++) {
        const start = pathPoints[i];
        const end = pathPoints[i + 1];
        const lenSq = distanceSq(start, end);
        if (lenSq === 0) continue;

        let t = ((point.x - start.x) * (end.x - start.x) + (point.y - start.y) * (end.y - start.y)) / lenSq;
        t = Math.max(0, Math.min(1, t));
        const projection = { x: start.x + t * (end.x - start.x), y: start.y + t * (end.y - start.y) };
        if (distanceSq(point, projection) < thresholdSq) {
            return true;
        }
    }
    return false;
};

const generateNewRoundData = (settings: PathFinderSettings, vocabulary: string[]): RoundData | null => {
    for (let attempt = 0; attempt < 10; attempt++) {
        const BORDER = 60;
        const width = 800;
        const height = 500;

        // Use a spatial grid to ensure items don't overlap
        const cellSize = 75; // Increased from 60 to prevent overlap
        const gridCols = Math.floor(width / cellSize);
        const gridRows = Math.floor(height / cellSize);
        const grid = new Array(gridCols * gridRows).fill(false);
        const placeInGrid = (x: number, y: number) => {
            const gridX = Math.floor(x / cellSize);
            const gridY = Math.floor(y / cellSize);
            if (gridX < 0 || gridX >= gridCols || gridY < 0 || gridY >= gridRows) return false;
            const index = gridY * gridCols + gridX;
            if (grid[index]) return false;
            grid[index] = true;
            return true;
        };
        
        // 1. Generate Path
        const pathPoints: {x: number, y: number}[] = [];
        const numSegments = 5 + settings.pathComplexity + Math.floor(settings.itemCount / 4);
        const segmentLength = (width - BORDER * 2) / numSegments * 1.2;
        let currentAngle = (Math.random() - 0.5) * 0.5;

        let currentPoint = { x: BORDER + Math.random() * 50, y: height / 2 + (Math.random() - 0.5) * (height / 3) };
        pathPoints.push(currentPoint);

        for (let i = 0; i < numSegments; i++) {
            currentAngle += (Math.random() - 0.5) * 1.2;
            currentAngle = Math.max(-Math.PI / 2.2, Math.min(Math.PI / 2.2, currentAngle));
            
            let nextPoint = {
                x: currentPoint.x + Math.cos(currentAngle) * segmentLength,
                y: currentPoint.y + Math.sin(currentAngle) * segmentLength,
            };

            if (nextPoint.x > width - BORDER || nextPoint.x < BORDER || nextPoint.y < BORDER || nextPoint.y > height - BORDER) {
                 nextPoint = { // try to steer back
                    x: Math.max(BORDER, Math.min(width - BORDER, nextPoint.x)),
                    y: Math.max(BORDER, Math.min(height - BORDER, nextPoint.y)),
                };
                currentAngle += Math.PI; // reverse direction
            }
            
            currentPoint = nextPoint;
            pathPoints.push(currentPoint);
        }
        
        if (pathPoints.length < 2) continue;
        const finishPoint = pathPoints[pathPoints.length - 1];

        // 2. Generate Items
        const items: PathItem[] = [];
        let itemAttempts = 0;
        while (items.length < settings.itemCount && itemAttempts < 5000) {
            itemAttempts++;
            const newItemPos = {
                x: Math.random() * (width - BORDER * 2) + BORDER,
                y: Math.random() * (height - BORDER * 2) + BORDER
            };

            if (!placeInGrid(newItemPos.x, newItemPos.y)) {
                continue;
            }

            const newItem: PathItem = {
                id: items.length,
                ...newItemPos,
                isOnPath: isPointOnPath(newItemPos, pathPoints, 45),
                distanceToFinishSq: distanceSq(newItemPos, finishPoint),
                colorIndex: Math.floor(Math.random() * COLORS.length),
                shapeIndex: Math.floor(Math.random() * ShapeConstant.length),
                wordIndex: Math.floor(Math.random() * vocabulary.length),
            };
            items.push(newItem);
        }
        
        if (items.length < settings.itemCount) continue;

        // 3. Determine Targets
        let rule = settings.mode === 'dynamic' ? (Math.random() > 0.5 ? 'on-path' : 'off-path') : settings.mode;
        let potentialTargets = items.filter(item => item.isOnPath === (rule === 'on-path'));

        if (potentialTargets.length < settings.numberOfTargets) {
            rule = rule === 'on-path' ? 'off-path' : 'on-path';
            potentialTargets = items.filter(item => item.isOnPath === (rule === 'on-path'));
            if (potentialTargets.length < settings.numberOfTargets) continue;
        }

        potentialTargets.sort((a, b) => a.distanceToFinishSq - b.distanceToFinishSq);
        const targetItems = potentialTargets.slice(0, settings.numberOfTargets);

        const targetProperties = {
            colors: settings.stimuli.color ? new Set(targetItems.map(t => t.colorIndex)) : new Set<number>(),
            shapes: settings.stimuli.shape ? new Set(targetItems.map(t => t.shapeIndex)) : new Set<number>(),
            words: settings.stimuli.word ? new Set(targetItems.map(t => t.wordIndex)) : new Set<number>(),
        };
        
        return { items, pathPoints, finishPoint, targetItems, rule, targetProperties };
    }
    return null; // Failed to generate after retries
};

const PathFinderHtmlItem: React.FC<{ 
    item: PathItem;
    settings: PathFinderSettings;
    vocabulary: string[];
    isFaded: boolean;
    isTarget: boolean;
    gameState: PathFinderGameState;
}> = ({ item, settings, vocabulary, isFaded, isTarget, gameState }) => {
    const color = COLORS[item.colorIndex % COLORS.length];
    const word = vocabulary[item.wordIndex % vocabulary.length] || '';
    const ShapeComponent = ShapeConstant[item.shapeIndex % ShapeConstant.length];
    
    const showFullItem = gameState === 'memorizing' || (gameState === 'feedback' && isTarget);
    const showPlaceholder = gameState === 'responding' || (gameState === 'feedback' && !isTarget);

    let textColor = '#FFFFFF';
    if (settings.textColor === 'contrast' && showFullItem) {
        textColor = getContrastingTextColor(color);
    } else if (settings.textColor === 'random' && showFullItem) {
        let randomColorIndex;
        do {
            randomColorIndex = Math.floor(Math.random() * COLORS.length);
        } while (randomColorIndex === item.colorIndex);
        textColor = COLORS[randomColorIndex];
    }

    const itemStyle: React.CSSProperties = {
        position: 'absolute',
        left: `${(item.x / 800) * 100}%`,
        top: `${(item.y / 500) * 100}%`,
        transform: 'translate(-50%, -50%)',
        transition: 'opacity 0.3s ease-in-out, transform 0.3s ease',
        opacity: isFaded ? 0.2 : 1,
        pointerEvents: 'none',
        width: '60px',
        height: '60px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    };
    
    if (gameState === 'feedback' && isTarget) {
      itemStyle.transform += ' scale(1.1)';
    }

    return (
        <div style={itemStyle}>
            {isTarget && gameState === 'feedback' && (
                <div className="absolute inset-[-10px] rounded-full border-4 border-yellow-300 border-dashed animate-spin-slow"></div>
            )}
            {showFullItem && (
                <>
                    <ShapeComponent className="absolute w-full h-full" style={{ color: color }} />
                    <span className="relative font-bold text-sm" style={{ color: textColor, textShadow: '0 0 5px rgba(0,0,0,0.7)' }}>
                        {word}
                    </span>
                </>
            )}
            {showPlaceholder && (
                <div className="w-3 h-3 bg-white rounded-full shadow-lg"></div>
            )}
        </div>
    );
};

const PathFinderSettingsModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    settings: PathFinderSettings;
    onSettingsChange: (newSettings: PathFinderSettings) => void;
    isGameActive: boolean;
}> = ({ isOpen, onClose, settings, onSettingsChange, isGameActive }) => {
    if (!isOpen) return null;
    
    const handleValueChange = <K extends keyof PathFinderSettings>(key: K, value: PathFinderSettings[K]) => {
        onSettingsChange({ ...settings, [key]: value });
    };

    const handleStimulusChange = (stimulus: keyof PathFinderSettings['stimuli'], enabled: boolean) => {
        const newStimuli = { ...settings.stimuli, [stimulus]: enabled };
        // Ensure at least one stimulus is always enabled
        const enabledCount = Object.values(newStimuli).filter(Boolean).length;
        if (enabledCount === 0) return;
        onSettingsChange({ ...settings, stimuli: newStimuli });
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md max-h-[90vh] flex flex-col text-gray-800">
                <header className="p-4 border-b border-gray-200 flex justify-between items-center">
                    <h2 className="text-xl font-bold font-orbitron">Path Finder Settings</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl">&times;</button>
                </header>
                <main className="p-6 overflow-y-auto">
                  <fieldset disabled={isGameActive} className={isGameActive ? 'opacity-50 cursor-not-allowed' : ''}>
                    <div className="space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Game Mode</label>
                            <select value={settings.mode} onChange={(e) => handleValueChange('mode', e.target.value as PathGameMode)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
                                <option value="dynamic">Dynamic</option>
                                <option value="on-path">On Path Only</option>
                                <option value="off-path">Off Path Only</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Enabled Modalities</label>
                            <div className="mt-2 space-y-2 p-3 bg-gray-50 rounded-md border">
                                {Object.keys(settings.stimuli).map(key => {
                                    const sKey = key as keyof typeof settings.stimuli;
                                    const isChecked = settings.stimuli[sKey];
                                    const canBeDisabled = Object.values(settings.stimuli).filter(Boolean).length > 1;

                                    return (
                                        <div key={sKey} className="flex items-center">
                                            <input
                                                id={`stimulus-${sKey}`}
                                                type="checkbox"
                                                checked={isChecked}
                                                disabled={isChecked && !canBeDisabled}
                                                onChange={(e) => handleStimulusChange(sKey, e.target.checked)}
                                                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                                            />
                                            <label htmlFor={`stimulus-${sKey}`} className="ml-3 block text-sm font-medium capitalize text-gray-700">{sKey}</label>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-gray-700">Text Color (in Memorize Phase)</label>
                            <select value={settings.textColor} onChange={(e) => handleValueChange('textColor', e.target.value as PathTextColorMode)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
                                <option value="white">White</option>
                                <option value="contrast">Smart Contrast</option>
                                <option value="random">Random (No Match)</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="memorizationDuration" className="block text-sm font-medium text-gray-700">Memorization Time: <span className="font-bold">{settings.memorizationDuration}s</span></label>
                            <input id="memorizationDuration" type="range" min="0" max="15" value={settings.memorizationDuration} onChange={e => handleValueChange('memorizationDuration', parseInt(e.target.value, 10))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                        </div>
                        <div>
                            <label htmlFor="vocabulary" className="block text-sm font-medium text-gray-700">Vocabulary (comma-separated)</label>
                            <textarea id="vocabulary" value={settings.vocabulary} onChange={e => handleValueChange('vocabulary', e.target.value)} rows={3} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"></textarea>
                        </div>
                        <div>
                            <label htmlFor="itemCount" className="block text-sm font-medium text-gray-700">Total Item Count: <span className="font-bold">{settings.itemCount}</span></label>
                            <input id="itemCount" type="range" min="10" max="40" value={settings.itemCount} onChange={e => handleValueChange('itemCount', parseInt(e.target.value, 10))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                        </div>
                        <div>
                            <label htmlFor="pathComplexity" className="block text-sm font-medium text-gray-700">Path Complexity: <span className="font-bold">{settings.pathComplexity}</span></label>
                            <input id="pathComplexity" type="range" min="1" max="10" value={settings.pathComplexity} onChange={e => handleValueChange('pathComplexity', parseInt(e.target.value, 10))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                        </div>
                         <div>
                            <label htmlFor="numberOfTargets" className="block text-sm font-medium text-gray-700">Number of Targets: <span className="font-bold">{settings.numberOfTargets}</span></label>
                            <input id="numberOfTargets" type="range" min="1" max="5" value={settings.numberOfTargets} onChange={e => handleValueChange('numberOfTargets', parseInt(e.target.value, 10))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                        </div>
                    </div>
                  </fieldset>
                </main>
            </div>
        </div>
    );
};

const PathFinderGame: React.FC<{
    settings: PathFinderSettings;
    onSettingsChange: (newSettings: PathFinderSettings) => void;
}> = ({ settings, onSettingsChange }) => {
    const [gameState, setGameState] = useState<PathFinderGameState>('idle');
    const [roundData, setRoundData] = useState<RoundData | null>(null);
    const [userSelection, setUserSelection] = useState<PathFinderUserSelection>({ colorIndices: new Set(), shapeIndices: new Set(), wordIndices: new Set() });
    const [feedbackText, setFeedbackText] = useState('');
    const [score, setScore] = useState({ correct: 0, total: 0 });
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);

    const timerRef = useRef<number | null>(null);
    const roundTimeoutRef = useRef<number | null>(null);
    
    const vocabulary = useMemo(() => settings.vocabulary.split(',').map(w => w.trim().toUpperCase()).filter(Boolean), [settings.vocabulary]);
    
    const stopAllTimers = useCallback(() => {
        if (timerRef.current) clearInterval(timerRef.current);
        if (roundTimeoutRef.current) clearTimeout(roundTimeoutRef.current);
        timerRef.current = null;
        roundTimeoutRef.current = null;
    }, []);

    useEffect(() => {
        return () => stopAllTimers(); // Cleanup on component unmount
    }, [stopAllTimers]);
    
    const startNextRound = useCallback(() => {
        stopAllTimers();
        setUserSelection({ colorIndices: new Set(), shapeIndices: new Set(), wordIndices: new Set() });

        const newRoundData = generateNewRoundData(settings, vocabulary);

        if (newRoundData) {
            setRoundData(newRoundData);
            if (settings.memorizationDuration > 0) {
                setGameState('memorizing');
                let timeLeft = settings.memorizationDuration;
                setFeedbackText(`Memorize! ${timeLeft}s`);

                timerRef.current = window.setInterval(() => {
                    timeLeft--;
                    if (timeLeft > 0) {
                        setFeedbackText(`Memorize! ${timeLeft}s`);
                    } else {
                        stopAllTimers();
                        setGameState('responding');
                        const ruleText = newRoundData!.rule === 'on-path' ? 'ON the path' : 'OFF the path';
                        setFeedbackText(`Find the item ${ruleText}, closest to the finish line.`);
                    }
                }, 1000);

            } else {
                setGameState('responding');
                const ruleText = newRoundData.rule === 'on-path' ? 'ON the path' : 'OFF the path';
                setFeedbackText(`Find the item ${ruleText}, closest to the finish line.`);
            }
        } else {
            setFeedbackText("Error generating round. Try simpler settings.");
            setGameState('idle');
        }
    }, [settings, vocabulary, stopAllTimers]);

    const handleStart = () => {
        setScore({ correct: 0, total: 0 });
        startNextRound();
    };

    const handleStop = () => {
        stopAllTimers();
        setGameState('idle');
        setRoundData(null);
        setFeedbackText('');
    };
    
    const handleSelection = (type: 'color' | 'shape' | 'word', index: number) => {
        if (gameState !== 'responding') return;
        setUserSelection(prev => {
            const newSelection = { ...prev };
            const setKey = type === 'color' ? 'colorIndices' : type === 'shape' ? 'shapeIndices' : 'wordIndices';
            const newSet = new Set(prev[setKey]);
            if (newSet.has(index)) {
                newSet.delete(index);
            } else {
                newSet.add(index);
            }
            newSelection[setKey] = newSet;
            return newSelection;
        });
    };

    const handleSubmit = () => {
        if (gameState !== 'responding' || !roundData) return;

        const { targetProperties } = roundData;
        const correct =
            (!settings.stimuli.color || (targetProperties.colors.size === userSelection.colorIndices.size && [...targetProperties.colors].every(c => userSelection.colorIndices.has(c)))) &&
            (!settings.stimuli.shape || (targetProperties.shapes.size === userSelection.shapeIndices.size && [...targetProperties.shapes].every(s => userSelection.shapeIndices.has(s)))) &&
            (!settings.stimuli.word || (targetProperties.words.size === userSelection.wordIndices.size && [...targetProperties.words].every(w => userSelection.wordIndices.has(w))));
        
        if (correct) {
            setFeedbackText('Correct!');
            setScore(s => ({ correct: s.correct + 1, total: s.total + 1 }));
        } else {
            setFeedbackText('Incorrect. The correct items are highlighted.');
            setScore(s => ({ correct: s.correct, total: s.total + 1 }));
        }
        
        setGameState('feedback');
        roundTimeoutRef.current = window.setTimeout(startNextRound, 2500);
    };
    
    const isSubmitEnabled = gameState === 'responding' && roundData && 
        (!settings.stimuli.color || userSelection.colorIndices.size === roundData.targetProperties.colors.size) &&
        (!settings.stimuli.shape || userSelection.shapeIndices.size === roundData.targetProperties.shapes.size) &&
        (!settings.stimuli.word || userSelection.wordIndices.size === roundData.targetProperties.words.size);

    const pathD = useMemo(() => {
        if (!roundData?.pathPoints || roundData.pathPoints.length < 2) return "";
        let pathString = `M ${roundData.pathPoints[0].x} ${roundData.pathPoints[0].y}`;
        for (let i = 0; i < roundData.pathPoints.length - 1; i++) {
            const p1 = roundData.pathPoints[i];
            const p2 = roundData.pathPoints[i + 1];
            const midPoint = { x: (p1.x + p2.x) / 2, y: (p1.y + p2.y) / 2 };
            pathString += ` Q ${p1.x} ${p1.y}, ${midPoint.x} ${midPoint.y}`;
        }
        const last = roundData.pathPoints[roundData.pathPoints.length - 1];
        pathString += ` T ${last.x} ${last.y}`;
        return pathString;
    }, [roundData]);
    
    return (
      <div className="flex flex-col h-full items-center justify-between text-white">
        <PathFinderSettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} settings={settings} onSettingsChange={onSettingsChange} isGameActive={gameState !== 'idle'}/>
        
        <header className="w-full flex justify-between items-center p-4">
          <div className="text-left">
            <h3 className="text-xl font-bold font-orbitron">Path Finder</h3>
            <p className="text-sm text-slate-300">Score: {score.correct} / {score.total} | Accuracy: {score.total > 0 ? ((score.correct/score.total)*100).toFixed(0) : '0'}%</p>
          </div>
          <button onClick={() => setIsSettingsOpen(true)} className="p-2 text-slate-300 hover:text-white rounded-full transition-colors" aria-label="Open Path Finder settings">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
          </button>
        </header>

        <div className="w-full flex-grow flex items-center justify-center p-2">
            <div className="w-full max-w-4xl bg-slate-800 rounded-lg shadow-lg aspect-[8/5] relative overflow-hidden">
                {gameState === 'idle' && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <h2 className="text-2xl font-bold mb-4">Welcome to Path Finder</h2>
                        <button onClick={handleStart} className="px-6 py-3 bg-blue-600 hover:bg-blue-500 rounded-lg font-bold text-lg transition-colors">Start Game</button>
                    </div>
                )}
                {gameState !== 'idle' && roundData && (
                     <>
                        <svg viewBox="0 0 800 500" className="absolute inset-0 w-full h-full">
                           <path d="M500,500 L550,400 L600,450 L650,350 L700,420 L750,380 L800,450 L800,500 Z" fill="white" opacity="0.1" />
                           <path d={pathD} fill="none" stroke="#4f46e5" strokeWidth="8" strokeOpacity="0.8" strokeDasharray="15 15" />
                           {roundData.finishPoint && (
                            <g transform={`translate(${roundData.finishPoint.x}, ${roundData.finishPoint.y})`}>
                                <path d="M -15 -15 L 15 15 M -15 15 L 15 -15" stroke="#ef4444" strokeWidth="6">
                                    <animateTransform attributeName="transform" type="rotate" from="0" to="360" dur="5s" repeatCount="indefinite" />
                                </path>
                            </g>
                           )}
                        </svg>
                        {roundData.items.map(item => (
                            <PathFinderHtmlItem
                                key={item.id}
                                item={item}
                                settings={settings}
                                vocabulary={vocabulary}
                                gameState={gameState}
                                isFaded={gameState === 'feedback' && !roundData.targetItems.some(t => t.id === item.id)}
                                isTarget={roundData.targetItems.some(t => t.id === item.id)}
                            />
                        ))}
                     </>
                )}
            </div>
        </div>

        <footer className="w-full p-4 space-y-3">
             <div className={`h-8 text-center font-semibold text-lg ${feedbackText.includes('Correct') ? 'text-green-400' : feedbackText.includes('Incorrect') ? 'text-red-400' : 'text-yellow-300'}`}>
                {feedbackText}
            </div>

            {gameState !== 'idle' && (
              <div className="max-w-4xl mx-auto space-y-4">
                 <div className={`grid grid-cols-1 md:grid-cols-3 gap-4 ${gameState === 'memorizing' ? 'opacity-50 pointer-events-none' : ''}`}>
                    {settings.stimuli.color && (
                        <div className="p-2 rounded-lg bg-slate-800/50">
                            <span className="text-sm font-bold text-slate-300">Colors ({userSelection.colorIndices.size}/{roundData?.targetProperties.colors.size ?? '?'})</span>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {COLORS.slice(0,8).map((color, index) => (
                                  <button key={color} onClick={() => handleSelection('color', index)} style={{backgroundColor: color}} className={`w-8 h-8 rounded-md transition-all ${userSelection.colorIndices.has(index) ? 'ring-4 ring-offset-2 ring-offset-slate-900 ring-white' : ''}`}></button>
                              ))}
                            </div>
                        </div>
                    )}
                    {settings.stimuli.shape && (
                        <div className="p-2 rounded-lg bg-slate-800/50">
                            <span className="text-sm font-bold text-slate-300">Shapes ({userSelection.shapeIndices.size}/{roundData?.targetProperties.shapes.size ?? '?'})</span>
                              <div className="flex flex-wrap gap-2 mt-2">
                                 {ShapeConstant.map((ShapeComponent, index) => (
                                   <button key={index} onClick={() => handleSelection('shape', index)} className={`w-8 h-8 rounded-md transition-all flex items-center justify-center ${userSelection.shapeIndices.has(index) ? 'bg-slate-600 ring-2 ring-white' : 'bg-slate-700'}`}>
                                     <ShapeComponent className="w-6 h-6 text-white" />
                                   </button>
                                 ))}
                              </div>
                        </div>
                    )}
                    {settings.stimuli.word && (
                        <div className="p-2 rounded-lg bg-slate-800/50">
                            <span className="text-sm font-bold text-slate-300">Words ({userSelection.wordIndices.size}/{roundData?.targetProperties.words.size ?? '?'})</span>
                              <div className="flex flex-wrap gap-2 mt-2">
                                {vocabulary.slice(0, 8).map((word, index) => (
                                    <button key={index} onClick={() => handleSelection('word', index)} className={`px-2 py-1 rounded-md transition-all text-xs font-bold ${userSelection.wordIndices.has(index) ? 'bg-slate-600 ring-2 ring-white' : 'bg-slate-700'}`}>{word}</button>
                                ))}
                              </div>
                        </div>
                    )}
                 </div>

                <div className="flex justify-center space-x-4">
                  {gameState === 'responding' && (
                    <button onClick={handleSubmit} disabled={!isSubmitEnabled} className="px-8 py-2 bg-green-600 hover:bg-green-500 rounded-lg font-bold text-lg transition-colors disabled:bg-slate-600 disabled:text-slate-400 disabled:cursor-not-allowed">Submit</button>
                  )}
                  <button onClick={handleStop} className="px-8 py-2 bg-red-600 hover:bg-red-500 rounded-lg font-bold text-lg transition-colors">Stop Game</button>
                </div>
              </div>
            )}
        </footer>
      </div>
    );
};

// --- CCT GAME (NEW REWRITE) ---

const speak = (text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.2;
        window.speechSynthesis.speak(utterance);
    } catch (error) {
        console.error("Speech synthesis error:", error);
    }
};

const CCTSettingsModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    settings: CCTSettings;
    onSettingsChange: (newSettings: CCTSettings) => void;
    isGameActive: boolean;
}> = ({ isOpen, onClose, settings, onSettingsChange, isGameActive }) => {
    if (!isOpen) return null;

    const handleValueChange = <K extends keyof CCTSettings>(key: K, value: CCTSettings[K]) => {
        onSettingsChange({ ...settings, [key]: value });
    };

    const handleStimulusChange = (stimulus: 'visual' | 'audio', enabled: boolean) => {
        const newSettings = { ...settings, [stimulus]: enabled };
        if (!newSettings.visual && !newSettings.audio) {
            newSettings[stimulus === 'visual' ? 'audio' : 'visual'] = true;
        }
        onSettingsChange(newSettings);
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800/80 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] flex flex-col text-white">
                <header className="p-4 border-b border-slate-700/50 flex justify-between items-center">
                    <h2 className="text-xl font-bold font-orbitron">CCT Settings</h2>
                    <button onClick={onClose} className="text-slate-400 hover:text-white text-2xl transition-colors">&times;</button>
                </header>
                <main className="p-6 overflow-y-auto">
                    <fieldset disabled={isGameActive} className={isGameActive ? 'opacity-50 cursor-not-allowed' : ''}>
                        <div className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-slate-300">Stimuli</label>
                                <div className="mt-2 space-y-2 p-3 bg-slate-900/50 rounded-md border border-slate-700">
                                    <div className="flex items-center">
                                        <input id="stimulus-visual" type="checkbox" checked={settings.visual} onChange={(e) => handleStimulusChange('visual', e.target.checked)} className="h-4 w-4 rounded border-slate-600 bg-slate-700 text-blue-500 focus:ring-blue-500"/>
                                        <label htmlFor="stimulus-visual" className="ml-3 block text-sm font-medium text-slate-200">Visual (Number)</label>
                                    </div>
                                    <div className="flex items-center">
                                        <input id="stimulus-audio" type="checkbox" checked={settings.audio} onChange={(e) => handleStimulusChange('audio', e.target.checked)} className="h-4 w-4 rounded border-slate-600 bg-slate-700 text-blue-500 focus:ring-blue-500"/>
                                        <label htmlFor="stimulus-audio" className="ml-3 block text-sm font-medium text-slate-200">Audio (Spoken Number)</label>
                                    </div>
                                </div>
                            </div>

                            <div className="border-t border-slate-700 pt-4">
                                <label className="block text-sm font-medium text-slate-300">Interference</label>
                                <div className="mt-2 space-y-2 p-3 bg-slate-900/50 rounded-md border border-slate-700">
                                     <div className="flex items-center">
                                        <input id="interferenceEnabled" type="checkbox" checked={settings.interferenceEnabled} onChange={(e) => handleValueChange('interferenceEnabled', e.target.checked)} className="h-4 w-4 rounded border-slate-600 bg-slate-700 text-blue-500 focus:ring-blue-500"/>
                                        <label htmlFor="interferenceEnabled" className="ml-3 block text-sm font-medium text-slate-200">Enable Interference</label>
                                    </div>
                                    {settings.interferenceEnabled && (
                                        <div className="pl-7 space-y-4 pt-2 border-l-2 border-slate-700 ml-2 mt-2">
                                            <div>
                                                <label htmlFor="interferenceChance" className="block text-sm font-medium text-slate-300">Chance: <span className="font-bold">{settings.interferenceChance}%</span></label>
                                                <input id="interferenceChance" type="range" min="0" max="100" value={settings.interferenceChance} onChange={e => handleValueChange('interferenceChance', parseInt(e.target.value, 10))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500 mt-1" />
                                            </div>
                                            <div>
                                                <label htmlFor="interferenceVocabulary" className="block text-sm font-medium text-slate-300">Words (comma-separated)</label>
                                                <textarea id="interferenceVocabulary" value={settings.interferenceVocabulary} onChange={e => handleValueChange('interferenceVocabulary', e.target.value)} rows={2} className="mt-1 block w-full px-3 py-2 bg-slate-700 text-white border border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"></textarea>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                            
                            <div className="border-t border-slate-700 pt-4 space-y-6">
                                <div className="flex items-center">
                                    <input id="adaptive" type="checkbox" checked={settings.adaptive} onChange={(e) => handleValueChange('adaptive', e.target.checked)} className="h-4 w-4 rounded border-slate-600 bg-slate-700 text-blue-500 focus:ring-blue-500"/>
                                    <label htmlFor="adaptive" className="ml-3 block text-sm font-medium text-slate-200">Adaptive Speed</label>
                                </div>
                                <div className="flex items-center">
                                    <input id="showCorrectAnswer" type="checkbox" checked={settings.showCorrectAnswer} onChange={(e) => handleValueChange('showCorrectAnswer', e.target.checked)} className="h-4 w-4 rounded border-slate-600 bg-slate-700 text-blue-500 focus:ring-blue-500"/>
                                    <label htmlFor="showCorrectAnswer" className="ml-3 block text-sm font-medium text-slate-200">Show correct answer on error</label>
                                </div>
                                <div>
                                    <label htmlFor="windowSize" className="block text-sm font-medium text-slate-300">Numbers to Sum: <span className="font-bold">{settings.windowSize}</span></label>
                                    <input id="windowSize" type="range" min="2" max="5" value={settings.windowSize} onChange={e => handleValueChange('windowSize', parseInt(e.target.value, 10))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500" />
                                </div>
                                 <div>
                                    <label htmlFor="trials" className="block text-sm font-medium text-slate-300">Number of Trials: <span className="font-bold">{settings.trials}</span></label>
                                    <input id="trials" type="range" min="10" max="100" value={settings.trials} onChange={e => handleValueChange('trials', parseInt(e.target.value, 10))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500" />
                                </div>
                                <div>
                                    <label htmlFor="speed" className="block text-sm font-medium text-slate-300">Base Speed (ms): <span className="font-bold">{settings.speed}</span></label>
                                    <input id="speed" type="range" min="500" max="5000" step="100" value={settings.speed} onChange={e => handleValueChange('speed', parseInt(e.target.value, 10))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500" />
                                </div>
                                 <div>
                                    <label htmlFor="maxNumber" className="block text-sm font-medium text-slate-300">Maximum Number: <span className="font-bold">{settings.maxNumber}</span></label>
                                    <input id="maxNumber" type="range" min="2" max="9" value={settings.maxNumber} onChange={e => handleValueChange('maxNumber', parseInt(e.target.value, 10))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500" />
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </main>
            </div>
        </div>
    );
};

const AuroraBackground = () => (
    <div className="absolute inset-0 overflow-hidden -z-10">
        <div 
            className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-rose-500/30 rounded-full filter blur-3xl opacity-50 animate-[aurora-1_20s_ease-in-out_infinite]"
            style={{ animationDelay: '0s' }}
        ></div>
        <div 
            className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-blue-500/30 rounded-full filter blur-3xl opacity-50 animate-[aurora-2_20s_ease-in-out_infinite]"
            style={{ animationDelay: '5s' }}
        ></div>
    </div>
);

const CCTGame: React.FC<{
    settings: CCTSettings;
    onSettingsChange: (newSettings: CCTSettings) => void;
}> = ({ settings, onSettingsChange }) => {
    const [gameState, setGameState] = useState<CCTGameState>('idle');
    const [phase, setPhase] = useState<CCTPhase>('presenting');
    const [trial, setTrial] = useState(0);
    const [score, setScore] = useState({ correct: 0, total: 0 });
    const [currentWindow, setCurrentWindow] = useState<number[]>([]);
    const [presentationIndex, setPresentationIndex] = useState(0);
    const [currentStimulus, setCurrentStimulus] = useState<number | null>(null);
    const [interferenceWord, setInterferenceWord] = useState<string | null>(null);
    const [userInput, setUserInput] = useState('');
    const [feedback, setFeedback] = useState<{ correct: boolean, expected: number } | null>(null);
    const [adaptiveSpeed, setAdaptiveSpeed] = useState(settings.speed);
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    
    // Main timer ref for the game loop.
    const timerRef = useRef<number | null>(null);

    // --- GAME LOGIC ---

    const startGame = useCallback(() => {
        if (timerRef.current) clearTimeout(timerRef.current);
        setTrial(0);
        setScore({ correct: 0, total: 0 });
        setUserInput('');
        setFeedback(null);
        setAdaptiveSpeed(settings.speed);
        const initialWindow = Array.from({ length: settings.windowSize }, () => Math.floor(Math.random() * (settings.maxNumber + 1)));
        setCurrentWindow(initialWindow);
        setPresentationIndex(0);
        setGameState('running');
        setPhase('presenting');
    }, [settings]);

    const stopGame = () => {
        if (timerRef.current) clearTimeout(timerRef.current);
        setGameState('idle');
    };

    const advanceTrial = useCallback(() => {
        if (trial + 1 >= settings.trials) {
            setGameState('finished');
            return;
        }
        const nextTrial = trial + 1;
        const newNumber = Math.floor(Math.random() * (settings.maxNumber + 1));
        const willInterfere = settings.interferenceEnabled && Math.random() < (settings.interferenceChance / 100);

        setTrial(nextTrial);
        setCurrentWindow(prev => [...prev.slice(1), newNumber]);
        setUserInput('');
        setFeedback(null);
        setPhase(willInterfere ? 'interfering' : 'presenting');
    }, [trial, settings]);

    // Effect for handling the game loop based on phase
    useEffect(() => {
        if (gameState !== 'running') return;

        let currentTimer: number | undefined;

        if (phase === 'interfering') {
            const vocab = settings.interferenceVocabulary.split(',').map(w => w.trim()).filter(Boolean);
            if (vocab.length > 0) {
                const word = vocab[Math.floor(Math.random() * vocab.length)];
                setInterferenceWord(word);
                if (settings.audio) speak(word);
            }
            currentTimer = window.setTimeout(() => {
                setInterferenceWord(null);
                setPhase('presenting');
            }, 1000); // Interference duration
        } else if (phase === 'presenting') {
            if (trial === 0) { // Initial window presentation
                if (presentationIndex >= settings.windowSize) {
                    setPhase('responding');
                    return;
                }
                const num = currentWindow[presentationIndex];
                setCurrentStimulus(num);
                if (settings.audio) speak(String(num));
                currentTimer = window.setTimeout(() => {
                    setCurrentStimulus(null);
                    const nextTimer = window.setTimeout(() => setPresentationIndex(p => p + 1), 500);
                    timerRef.current = nextTimer;
                }, Math.max(200, adaptiveSpeed - 500));
            } else { // Subsequent trials
                const newNumber = currentWindow[currentWindow.length - 1];
                setCurrentStimulus(newNumber);
                if (settings.audio) speak(String(newNumber));
                currentTimer = window.setTimeout(() => {
                    setCurrentStimulus(null);
                    setPhase('responding');
                }, adaptiveSpeed);
            }
        } else if (phase === 'feedback') {
            const feedbackDuration = feedback?.correct ? 2000 : 1500;
            currentTimer = window.setTimeout(advanceTrial, feedbackDuration);
        }

        timerRef.current = currentTimer;

        return () => {
            if (currentTimer) clearTimeout(currentTimer);
        };
    }, [gameState, phase, trial, presentationIndex, adaptiveSpeed, currentWindow, settings, advanceTrial, feedback]);

    // Cleanup timer on unmount
    useEffect(() => () => {
        if (timerRef.current) clearTimeout(timerRef.current);
    }, []);

    const handleSubmit = () => {
        if (phase !== 'responding' || userInput === '') return;
        
        const correctSum = currentWindow.reduce((a, b) => a + b, 0);
        const userAnswer = parseInt(userInput, 10);
        const isCorrect = userAnswer === correctSum;
        
        setScore(s => ({ correct: s.correct + (isCorrect ? 1 : 0), total: s.total + 1 }));
        setFeedback({ correct: isCorrect, expected: correctSum });
        
        if (settings.adaptive) {
            setAdaptiveSpeed(speed => isCorrect ? Math.max(500, speed * 0.9) : Math.min(5000, speed * 1.1));
        }
        
        setPhase('feedback');
    };

    const handleNumberInput = (num: string) => {
        if (phase !== 'responding') return;
        setUserInput(prev => (prev + num).slice(0, 3));
    };
    const handleClear = () => { setUserInput(''); };

    const accuracy = score.total > 0 ? ((score.correct / score.total) * 100).toFixed(0) : 0;
    const helperText = `Recall the last ${settings.windowSize} numbers and enter the sum.`;
    
    let feedbackColorClass = 'border-transparent';
    if(phase === 'feedback' && feedback) {
        feedbackColorClass = feedback.correct ? 'border-green-500/80' : 'border-red-500/80';
    }

    return (
        <div className="flex flex-col h-full items-center justify-between text-white relative isolate">
            <AuroraBackground />
            <CCTSettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} settings={settings} onSettingsChange={onSettingsChange} isGameActive={gameState !== 'idle'}/>
            
            <header className="w-full flex justify-between items-center p-4 z-10">
                <div className="text-left">
                    <h3 className="text-xl font-bold font-orbitron">Sliding Sum</h3>
                    <p className="text-sm text-slate-300">Trial: {gameState === 'idle' ? 0 : trial + 1} / {settings.trials} | Score: {score.correct}/{score.total} ({accuracy}%)</p>
                </div>
                <button onClick={() => setIsSettingsOpen(true)} className="p-2 text-slate-300 hover:text-white rounded-full transition-colors" aria-label="Open CCT settings">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                </button>
            </header>
            
            <div className="w-full flex-grow flex items-center justify-center p-2 z-10">
                 <div className="w-full max-w-sm bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl p-6 flex flex-col items-center justify-center space-y-4">
                    {gameState === 'idle' && <button onClick={startGame} className="px-6 py-3 bg-blue-600/80 hover:bg-blue-500/80 rounded-lg font-bold text-lg transition-colors">Start Game</button>}
                    {gameState === 'finished' && <div className="text-center"><h2 className="text-2xl font-bold mb-4 font-orbitron">Finished!</h2><p>Final Score: {score.correct}/{score.total} ({accuracy}%)</p><button onClick={startGame} className="mt-4 px-6 py-3 bg-blue-600/80 hover:bg-blue-500/80 rounded-lg font-bold text-lg transition-colors">Play Again</button></div>}
                    
                    {gameState === 'running' && (
                        <>
                            <div className={`relative w-32 h-32 rounded-full border-4 flex items-center justify-center transition-all duration-300 ${feedbackColorClass}`}>
                                <div className="absolute inset-0 bg-slate-900/50 rounded-full"></div>
                                {settings.visual || phase === 'interfering' ? (
                                    <div className="relative text-6xl font-bold font-orbitron transition-opacity duration-200">
                                       {phase === 'interfering' && interferenceWord && (
                                            <span className="text-4xl text-yellow-400">{interferenceWord}</span>
                                       )}
                                       {phase === 'presenting' && currentStimulus !== null && (
                                            <span className="opacity-100">{currentStimulus}</span>
                                       )}
                                       {(phase === 'responding' || (phase === 'presenting' && currentStimulus === null)) && (
                                            <span className="opacity-50 text-slate-500 animate-pulse">?</span>
                                       )}
                                    </div>
                                ) : (
                                    <div className="relative text-6xl font-bold font-orbitron text-slate-500 animate-pulse">?</div>
                                )}
                                {phase === 'feedback' && feedback && (
                                     <div className={`absolute text-2xl font-bold ${feedback.correct ? 'text-green-400' : 'text-red-400'}`}>
                                        {feedback.correct ? '✓' : (settings.showCorrectAnswer ? `Σ = ${feedback.expected}` : '✗')}
                                    </div>
                                )}
                            </div>
                            <p className="text-sm text-slate-400 h-5">{phase === 'responding' ? helperText : phase === 'interfering' ? 'Interference!' : ''}</p>
                            <div className={`w-full bg-slate-900/70 rounded-md p-4 text-right text-4xl font-orbitron h-20 flex items-center justify-end border-2 transition-colors duration-300 ${feedbackColorClass}`}>
                               <span>{userInput}</span>
                               <span className="w-1.5 h-10 bg-slate-400 cursor-blink ml-2"></span>
                            </div>
                            <div className="grid grid-cols-3 gap-3 w-full">
                                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
                                    <button key={num} onClick={() => handleNumberInput(num)} disabled={phase !== 'responding'} className="py-3 bg-slate-700/50 backdrop-blur-sm rounded-lg font-bold text-xl transition-all hover:bg-slate-600/70 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100">{num}</button>
                                ))}
                                <button onClick={handleClear} disabled={phase !== 'responding'} className="py-3 bg-slate-700/50 backdrop-blur-sm rounded-lg font-bold text-xl transition-all hover:bg-slate-600/70 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100">C</button>
                                <button onClick={() => handleNumberInput('0')} disabled={phase !== 'responding'} className="py-3 bg-slate-700/50 backdrop-blur-sm rounded-lg font-bold text-xl transition-all hover:bg-slate-600/70 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100">0</button>
                                <button onClick={handleSubmit} disabled={phase !== 'responding' || userInput === ''} className="py-3 bg-green-600/60 backdrop-blur-sm rounded-lg font-bold text-xl transition-all hover:bg-green-500/80 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100">OK</button>
                            </div>
                        </>
                    )}
                </div>
            </div>

            <footer className="w-full p-4 z-10">
                {gameState === 'running' && <button onClick={stopGame} className="block mx-auto mt-4 px-8 py-2 bg-red-600/80 hover:bg-red-500/80 rounded-lg font-bold text-lg transition-colors">Stop Game</button>}
            </footer>
        </div>
    );
};

const CreatorStudio: React.FC<CreatorStudioProps> = ({ autoSave }) => {
  const [activeGame, setActiveGame] = useState<GameType>('path-finder');
  const [studioSettings, setStudioSettings] = useState<StudioSettings>(loadStudioSettings);

  useEffect(() => {
    if (autoSave) {
        try {
            localStorage.setItem('chunkCoreCreatorStudioSettings', JSON.stringify(studioSettings));
        } catch (error) {
            console.error("Error auto-saving Creator Studio settings:", error);
        }
    }
  }, [studioSettings, autoSave]);

  const handleSettingsChange = (newSettings: StudioSettings) => {
    setStudioSettings(newSettings);
  };
  
  return (
    <div className="bg-slate-900 text-white rounded-xl shadow-2xl p-2 sm:p-4 flex flex-col min-h-[85vh] relative overflow-hidden">
      <div className="flex border-b border-slate-700 mb-4 px-2 sm:px-4 z-10">
        <button 
          onClick={() => setActiveGame('path-finder')} 
          className={`py-2 px-4 font-bold transition-colors ${activeGame === 'path-finder' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-slate-400 hover:text-white'}`}
        >
          Path Finder
        </button>
        <button 
          onClick={() => setActiveGame('cct')} 
          className={`py-2 px-4 font-bold transition-colors ${activeGame === 'cct' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-slate-400 hover:text-white'}`}
        >
          CCT
        </button>
      </div>
      <div className="flex-grow flex flex-col">
        {activeGame === 'path-finder' && <PathFinderGame settings={studioSettings.pathFinder} onSettingsChange={(pfSettings) => handleSettingsChange({...studioSettings, pathFinder: pfSettings})} />}
        {activeGame === 'cct' && <CCTGame settings={studioSettings.cct} onSettingsChange={(cctSettings) => handleSettingsChange({...studioSettings, cct: cctSettings})} />}
      </div>
    </div>
  );
};

export default CreatorStudio;
