
import React from 'react';
import { GameSettings, VisualMode, StimulusType, AudioGUIVisibility, ResponseLayout } from '../types';
import { TONES, COLORS, SHAPES, LETTERS } from '../constants';

interface SettingsProps {
  settings: GameSettings;
  onSettingsChange: (settings: GameSettings) => void;
  isGameActive: boolean;
  onClose: () => void;
  autoSave: boolean;
  onAutoSaveChange: (enabled: boolean) => void;
}

const Settings: React.FC<SettingsProps> = ({ settings, onSettingsChange, isGameActive, onClose, autoSave, onAutoSaveChange }) => {

  const handleSettingChange = (field: keyof GameSettings, value: any) => {
    onSettingsChange({ ...settings, [field]: value });
  };
  
  const handleStimulusChange = (stimulus: StimulusType, key: 'enabled' | 'count', value: boolean | number) => {
    let updatedStimuli = {
      ...settings.stimuli,
      [stimulus]: { ...settings.stimuli[stimulus], [key]: value }
    };

    // Dependency logic: Visual stimuli require position.
    if ((stimulus === 'text' || stimulus === 'shape' || stimulus === 'color') && key === 'enabled' && value) {
      updatedStimuli.position = { ...updatedStimuli.position, enabled: true };
    }
    
    // Disabling a parent disables children
    if (stimulus === 'position' && key === 'enabled' && !value) {
      updatedStimuli.color = { ...updatedStimuli.color, enabled: false };
      updatedStimuli.shape = { ...updatedStimuli.shape, enabled: false };
      updatedStimuli.text = { ...updatedStimuli.text, enabled: false };
    }

    onSettingsChange({ ...settings, stimuli: updatedStimuli });
  };
  
  const handleVisualModeChange = (mode: VisualMode) => {
      onSettingsChange({ ...settings, visualMode: mode });
  }
  
  const getMaxPositionCount = (visualMode: VisualMode, gridSize: number) => {
     return {
        [VisualMode.TwoDGrid]: gridSize * gridSize,
        [VisualMode.ThreeDGrid]: 6 * gridSize * gridSize,
        [VisualMode.ThreeDCube]: gridSize * gridSize * gridSize,
        [VisualMode.ThreeDSpheres]: 6 * gridSize * gridSize,
    }[visualMode];
  }

  const handleGridSizeChange = (size: number) => {
      const maxPos = getMaxPositionCount(settings.visualMode, size);
      let newStimuliSettings = settings.stimuli;

      if (settings.stimuli.position.count > maxPos) {
          newStimuliSettings = {
              ...settings.stimuli,
              position: { ...settings.stimuli.position, count: maxPos }
          };
      }
      
      onSettingsChange({ ...settings, gridSize: size, stimuli: newStimuliSettings });
  }

  const fieldsetClassName = isGameActive ? 'opacity-50 cursor-not-allowed' : '';
  const selectInputClassName = "mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white text-gray-800 border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md";
  
  const is3DMode = settings.visualMode === VisualMode.ThreeDCube || settings.visualMode === VisualMode.ThreeDGrid || settings.visualMode === VisualMode.ThreeDSpheres;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-2xl w-full max-w-md max-h-[90vh] flex flex-col">
            <header className="p-4 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-800">Settings</h2>
                <button onClick={onClose} className="text-gray-400 hover:text-gray-600">&times;</button>
            </header>
            <main className="p-6 overflow-y-auto">
              <div className="flex items-center p-3 mb-4 bg-gray-50 rounded-lg border">
                  <input id="autoSave" type="checkbox" checked={autoSave} onChange={(e) => onAutoSaveChange(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"/>
                  <label htmlFor="autoSave" className="ml-3 block text-sm font-medium text-gray-700">Automatically save settings</label>
              </div>
              <fieldset disabled={isGameActive} className={fieldsetClassName}>
                <div className="space-y-4">
                  {/* Trials, N-Back, etc. */}
                  <div>
                    <label htmlFor="trials" className="block text-sm font-medium text-gray-700">Trials</label>
                    <input type="number" id="trials" value={settings.trials} onChange={(e) => handleSettingChange('trials', parseInt(e.target.value))} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"/>
                  </div>
                  <div>
                    <label htmlFor="nValue" className="block text-sm font-medium text-gray-700">N-Back Level</label>
                    <select id="nValue" value={settings.nValue} onChange={(e) => handleSettingChange('nValue', parseInt(e.target.value))} className={selectInputClassName}>
                      {Array.from({length: 9}, (_, i) => i + 1).map(n => <option key={n} value={n}>{n}-Back</option>)}
                    </select>
                  </div>
                   <div>
                    <label htmlFor="visualMode" className="block text-sm font-medium text-gray-700">Visual Mode</label>
                    <select id="visualMode" value={settings.visualMode} onChange={(e) => handleVisualModeChange(e.target.value as VisualMode)} className={selectInputClassName}>
                      {Object.values(VisualMode).map(mode => <option key={mode} value={mode}>{mode}</option>)}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="responseLayout" className="block text-sm font-medium text-gray-700">Response Layout</label>
                    <select id="responseLayout" value={settings.responseLayout} onChange={(e) => handleSettingChange('responseLayout', e.target.value as ResponseLayout)} className={selectInputClassName}>
                      {Object.values(ResponseLayout).map(layout => <option key={layout} value={layout}>{layout}</option>)}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="gridSize" className="block text-sm font-medium text-gray-700">{settings.visualMode === VisualMode.TwoDGrid ? 'Grid Size' : 'Cube Size'}</label>
                    <select id="gridSize" value={settings.gridSize} onChange={(e) => handleGridSizeChange(parseInt(e.target.value))} className={selectInputClassName}>
                      <option value="3">3x3{settings.visualMode !== VisualMode.TwoDGrid && 'x3'}</option>
                      <option value="4">4x4{settings.visualMode !== VisualMode.TwoDGrid && 'x4'}</option>
                      <option value="5">5x5{settings.visualMode !== VisualMode.TwoDGrid && 'x5'}</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="visualizerHeight" className="block text-sm font-medium text-gray-700">Visualizer Height</label>
                    <div className="mt-2 pl-1 flex items-center space-x-3">
                       <input
                          type="range"
                          id="visualizerHeight"
                          min="400"
                          max="1200"
                          step="10"
                          value={settings.visualizerHeight}
                          onChange={(e) => handleSettingChange('visualizerHeight', parseInt(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                       <span className="text-sm font-semibold w-16 text-right">{settings.visualizerHeight}px</span>
                    </div>
                  </div>

                  {is3DMode && (
                    <div className="border-t border-gray-200 pt-4">
                      <h3 className="text-md font-medium text-gray-800">Visuals</h3>
                      <div className="mt-2 space-y-4">
                        <div>
                          <label htmlFor="cameraAngleX" className="block text-sm font-medium text-gray-700">Camera Pitch</label>
                          <div className="mt-2 pl-1 flex items-center space-x-3">
                             <input type="range" id="cameraAngleX" min="-90" max="0" value={settings.cameraAngleX} onChange={(e) => handleSettingChange('cameraAngleX', parseInt(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                             <span className="text-sm font-semibold w-12 text-right">{settings.cameraAngleX}°</span>
                          </div>
                        </div>
                        {settings.visualMode === VisualMode.ThreeDCube && (
                          <div>
                            <label htmlFor="cubeGap" className="block text-sm font-medium text-gray-700">Cube Spacing</label>
                            <div className="mt-2 pl-1 flex items-center space-x-3">
                               <input type="range" id="cubeGap" min="0" max="50" value={settings.cubeGap} onChange={(e) => handleSettingChange('cubeGap', parseInt(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                               <span className="text-sm font-semibold w-12 text-right">{settings.cubeGap}%</span>
                            </div>
                          </div>
                        )}
                         {settings.visualMode === VisualMode.ThreeDSpheres && (
                          <>
                            <div>
                              <label htmlFor="sphereCount" className="block text-sm font-medium text-gray-700">Decorative Spheres</label>
                              <div className="mt-2 pl-1 flex items-center space-x-3">
                                 <input type="range" id="sphereCount" min="0" max="50" value={settings.sphereCount} onChange={(e) => handleSettingChange('sphereCount', parseInt(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                                 <span className="text-sm font-semibold w-12 text-right">{settings.sphereCount}</span>
                              </div>
                            </div>
                             <div>
                              <label htmlFor="sphereSpeed" className="block text-sm font-medium text-gray-700">Overall Sphere Speed</label>
                              <div className="mt-2 pl-1 flex items-center space-x-3">
                                 <input type="range" id="sphereSpeed" min="1" max="15" step="1" value={settings.sphereSpeed} onChange={(e) => handleSettingChange('sphereSpeed', parseInt(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                                 <span className="text-sm font-semibold w-12 text-right">{settings.sphereSpeed}</span>
                              </div>
                            </div>
                            <div className="flex items-center">
                              <input id="respawnSphere" type="checkbox" checked={settings.respawnSphere} onChange={(e) => handleSettingChange('respawnSphere', e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"/>
                              <label htmlFor="respawnSphere" className="ml-3 block text-sm font-medium text-gray-700">Respawn Sphere After Collision</label>
                            </div>
                             <div className="flex items-center">
                              <input id="interferenceEnabled" type="checkbox" checked={settings.interferenceEnabled} onChange={(e) => handleSettingChange('interferenceEnabled', e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"/>
                              <label htmlFor="interferenceEnabled" className="ml-3 block text-sm font-medium text-gray-700">Enable Interference</label>
                            </div>
                            {settings.interferenceEnabled && (
                              <div>
                                <label htmlFor="interferencePercentage" className="block text-sm font-medium text-gray-700">Interference Chance</label>
                                <div className="mt-2 pl-1 flex items-center space-x-3">
                                    <input type="range" id="interferencePercentage" min="0" max="100" value={settings.interferencePercentage} onChange={(e) => handleSettingChange('interferencePercentage', parseInt(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                                    <span className="text-sm font-semibold w-12 text-right">{settings.interferencePercentage}%</span>
                                </div>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="border-t border-gray-200 pt-4">
                    <h3 className="text-md font-medium text-gray-800">Training Modalities</h3>
                    <div className="mt-2 space-y-4">
                       {Object.keys(settings.stimuli).map(key => {
                          const sKey = key as StimulusType;
                          const stimulus = settings.stimuli[sKey];
                          const getDependencyText = () => {
                             if ((sKey === 'text' || sKey === 'shape' || sKey === 'color') && !settings.stimuli.position.enabled) return '(requires position)';
                             return '';
                          }
                          const dependencyText = getDependencyText();
                          const isDisabled = !!dependencyText;
                          
                          const maxCount = {
                              audio: TONES.length,
                              position: getMaxPositionCount(settings.visualMode, settings.gridSize),
                              color: COLORS.length,
                              shape: SHAPES.length,
                              text: LETTERS.length,
                          }[sKey];

                          const hidePositionVariety = sKey === 'position' && (settings.visualMode === VisualMode.ThreeDGrid || settings.visualMode === VisualMode.ThreeDSpheres);

                          return (
                             <div key={key}>
                               <div className="flex items-center">
                                 <input id={`stimulus-${key}`} type="checkbox" checked={stimulus.enabled && !isDisabled} onChange={(e) => handleStimulusChange(sKey, 'enabled', e.target.checked)} disabled={isDisabled} className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 disabled:opacity-75"/>
                                 <label htmlFor={`stimulus-${key}`} className={`ml-3 block text-sm font-medium capitalize ${isDisabled ? 'text-gray-400' : 'text-gray-700'}`}>{key} {dependencyText}</label>
                               </div>
                               {stimulus.enabled && !isDisabled && sKey === 'audio' && (
                                <div className="mt-2 pl-7">
                                    <label htmlFor="audioGUIVisibility" className="block text-xs text-gray-500">GUI Display</label>
                                    <select 
                                      id="audioGUIVisibility" 
                                      value={settings.audioGUIVisibility} 
                                      onChange={(e) => handleSettingChange('audioGUIVisibility', e.target.value as AudioGUIVisibility)} 
                                      className="mt-1 block w-full pl-3 pr-10 py-1 text-xs bg-white text-gray-800 border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-md"
                                    >
                                      {Object.values(AudioGUIVisibility).map(mode => <option key={mode} value={mode}>{mode}</option>)}
                                    </select>
                                  </div>
                               )}
                               {stimulus.enabled && !isDisabled && !hidePositionVariety && (
                                   <div className="mt-2 pl-7 flex items-center space-x-3">
                                       <span className="text-xs text-gray-500">Variety</span>
                                       <input 
                                         type="range" 
                                         min="2" 
                                         max={maxCount} 
                                         value={stimulus.count} 
                                         onChange={(e) => handleStimulusChange(sKey, 'count', parseInt(e.target.value))} 
                                         className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                                        />
                                       <span className="text-sm font-semibold">{stimulus.count}</span>
                                   </div>
                               )}
                            </div>
                          );
                       })}
                    </div>
                  </div>
                </div>
              </fieldset>
            </main>
        </div>
    </div>
  );
};

export default Settings;
