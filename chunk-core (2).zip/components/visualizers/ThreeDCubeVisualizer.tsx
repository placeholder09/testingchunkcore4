import React, { useEffect } from 'react';
import { GameSettings, Stimulus, VisualStimulus } from '../../types';
import { COLORS, SHAPES, LETTERS } from '../../constants';

interface VisualizerProps {
  stimulus: Stimulus | null;
  settings: GameSettings;
  onVisualStimulusArrival: () => void;
}

const CubePiece: React.FC<{ 
  isActive: boolean; 
  stimulus?: VisualStimulus;
  inactiveOpacity: number;
  settings: GameSettings;
  cubeSize: number;
}> = ({ isActive, stimulus, inactiveOpacity, settings, cubeSize }) => {
  const faces = [
    { transform: `rotateY(0deg) translateZ(${cubeSize / 2}px)`, key: 'front' },
    { transform: `rotateY(180deg) translateZ(${cubeSize / 2}px)`, key: 'back' },
    { transform: `rotateY(90deg) translateZ(${cubeSize / 2}px)`, key: 'right' },
    { transform: `rotateY(-90deg) translateZ(${cubeSize / 2}px)`, key: 'left' },
    { transform: `rotateX(90deg) translateZ(${cubeSize / 2}px)`, key: 'top' },
    { transform: `rotateX(-90deg) translateZ(${cubeSize / 2}px)`, key: 'bottom' },
  ];

  const faceStyle: React.CSSProperties = {
    position: 'absolute',
    width: `${cubeSize}px`,
    height: `${cubeSize}px`,
    transition: 'all 0.3s ease',
  };
  
  const ShapeComponent = (isActive && stimulus && settings.stimuli.shape.enabled) ? SHAPES[stimulus.shape % SHAPES.length] : null;
  const LetterComponent = (isActive && stimulus && settings.stimuli.text.enabled) ? LETTERS[stimulus.text % LETTERS.length] : null;

  const activeColor = (isActive && stimulus && settings.stimuli.color.enabled) ? COLORS[stimulus.color % COLORS.length] : '#3B82F6'; // Default blue-500
  const activeBgColor = (ShapeComponent || LetterComponent) ? `${activeColor}B3` : activeColor; 

  const activeFaceStyle: React.CSSProperties = {
      ...faceStyle,
      backgroundColor: activeBgColor,
      border: `1px solid ${activeColor}`,
      opacity: 1,
  }

  const inactiveFaceStyle: React.CSSProperties = {
      ...faceStyle,
      backgroundColor: `rgba(147, 197, 253, ${inactiveOpacity * 0.5})`, // Brighter sky-300 base
      border: `1px solid rgba(59, 130, 246, ${inactiveOpacity})`, // Brighter blue-500 base
  }

  const contentContainerStyle: React.CSSProperties = {
    position: 'absolute',
    width: '100%',
    height: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transform: 'translateZ(0px)',
  }

  return (
    <div className="relative" style={{ width: `${cubeSize}px`, height: `${cubeSize}px`, transformStyle: 'preserve-3d' }}>
      {(ShapeComponent || LetterComponent) && (
        <div style={contentContainerStyle}>
          {ShapeComponent && (
            <div className="w-3/4 h-3/4" style={{ color: 'white', opacity: LetterComponent ? 0.7 : 1 }}>
              <ShapeComponent />
            </div>
          )}
          {LetterComponent && (
            <div className="absolute text-white font-bold" style={{ fontSize: `${cubeSize * 0.5}px`, textShadow: '0 0 5px black' }}>
              {LetterComponent}
            </div>
          )}
        </div>
      )}
      {faces.map(face => (
        <div
          key={face.key}
          style={{
              ... (isActive ? activeFaceStyle : inactiveFaceStyle),
              transform: face.transform
          }}
        />
      ))}
    </div>
  );
};


const ThreeDCubeVisualizer: React.FC<VisualizerProps> = ({ stimulus, settings, onVisualStimulusArrival }) => {
  const n = settings.gridSize;
  const totalCubes = n * n * n;
  const cubes = Array.from({ length: totalCubes }, (_, i) => i);
  
  const totalAssemblySize = 280;
  const step = totalAssemblySize / n;
  const gap = step * (settings.cubeGap / 100);
  const cubeSize = step - gap;

  const offset = (n - 1) / 2;
  const activePosition = stimulus?.visual?.position;

  useEffect(() => {
    if (stimulus) {
      onVisualStimulusArrival();
    }
  }, [stimulus, onVisualStimulusArrival]);

  return (
    <div className="w-full h-full perspective-container flex items-center justify-center">
       <div 
         className="w-full h-full relative rotating-cube" 
         style={{ 
           transformStyle: 'preserve-3d',
           '--camera-angle-x': `${settings.cameraAngleX}deg`
          } as React.CSSProperties}
        >
         {cubes.map(index => {
           const isActive = activePosition === index;
           const activeStimulus = isActive ? stimulus!.visual! : undefined;
           
           const x = (index % n) - offset;
           const y = Math.floor((index % (n*n)) / n) - offset;
           const z = Math.floor(index / (n*n)) - offset;
           
           return (
            <div key={index}
                 className="absolute"
                 style={{
                   top: '50%',
                   left: '50%',
                   transform: `
                     translateX(-50%) 
                     translateY(-50%) 
                     translate3d(${x * step}px, ${y * step}px, ${z * step}px)
                   `,
                   transformStyle: 'preserve-3d',
                 }}
            >
              <CubePiece 
                isActive={isActive}
                stimulus={activeStimulus}
                inactiveOpacity={settings.inactiveOpacity}
                settings={settings}
                cubeSize={cubeSize}
              />
            </div>
           )
         })}
      </div>
    </div>
  );
};

export default ThreeDCubeVisualizer;