import React, { useState, useEffect, useMemo, useRef } from 'react';
import { GameSettings, Stimulus } from '../../types';
import { COLORS, SHAPES, LETTERS } from '../../constants';

interface VisualizerProps {
  stimulus: Stimulus | null;
  settings: GameSettings;
  onVisualStimulusArrival: () => void;
}

interface SphereState {
  id: number;
  color: string;
  pos: { x: number; y: number; z: number };
  vel: { x: number; y: number; z: number };
  
  // For animation
  startPos?: { x: number; y: number; z: number };
  targetPos?: { x: number; y: number; z: number };
  startTime?: number; // performance.now()
  travelDuration?: number; // The calculated duration for this specific collision
  collidedTime?: number; // performance.now()
  targetFaceIndex?: number;
  targetCellIndex?: number;

  state: 'decorative' | 'colliding' | 'collided';
  opacity: number;
}

const CssSphere: React.FC<{ 
  color: string; 
  size: number;
  style?: React.CSSProperties 
}> = ({ color, size, style }) => {
  const slices = 10;
  const sliceAngle = 180 / slices;

  const sliceStyle: React.CSSProperties = {
    position: 'absolute',
    width: '100%',
    height: '100%',
    borderRadius: '50%',
    backgroundColor: color,
    opacity: 0.7,
  };

  const containerStyle: React.CSSProperties = {
    width: `${size}px`,
    height: `${size}px`,
    position: 'absolute',
    top: '50%',
    left: '50%',
    marginLeft: `-${size / 2}px`,
    marginTop: `-${size / 2}px`,
    transformStyle: 'preserve-3d',
    ...style,
  };

  return (
    <div style={containerStyle}>
      {Array.from({ length: slices }).map((_, i) => (
        <div
          key={i}
          style={{
            ...sliceStyle,
            transform: `rotateY(${i * sliceAngle}deg)`,
          }}
        />
      ))}
    </div>
  );
};


const GridFace: React.FC<{ 
    activeCell: number | null;
    gridSize: number;
    showImpact: boolean;
    stimulus: Stimulus | null;
    settings: GameSettings;
}> = ({ activeCell, gridSize, showImpact, stimulus, settings }) => {
    return (
        <div 
          className="grid gap-1 w-full h-full p-1"
          style={{
              gridTemplateColumns: `repeat(${gridSize}, 1fr)`,
              gridTemplateRows: `repeat(${gridSize}, 1fr)`
          }}
        >
            {Array.from({ length: gridSize * gridSize }).map((_, i) => {
                const isActive = activeCell === i;
                const shouldHighlight = isActive && showImpact;

                const ShapeComponent = shouldHighlight && stimulus && settings.stimuli.shape.enabled 
                  ? SHAPES[stimulus.visual!.shape % SHAPES.length] 
                  : null;
                
                 const LetterComponent = shouldHighlight && stimulus && settings.stimuli.text.enabled
                  ? LETTERS[stimulus.visual!.text % LETTERS.length]
                  : null;

                const highlightColor = (shouldHighlight && stimulus && settings.stimuli.color.enabled)
                  ? COLORS[stimulus.visual!.color % COLORS.length]
                  : '#3B82F6';

                const cellStyle: React.CSSProperties = {
                    backgroundColor: shouldHighlight ? highlightColor : 'transparent',
                    boxShadow: shouldHighlight ? `0 0 10px 2px ${highlightColor}` : 'none',
                    borderColor: 'rgba(147, 197, 253, 0.5)',
                    transition: 'all 0.1s ease-in-out'
                }

                return (
                    <div key={i} className={`border rounded-sm flex items-center justify-center relative`} style={cellStyle}>
                        {ShapeComponent && (
                            <div className="w-3/4 h-3/4 text-white" style={{opacity: LetterComponent ? 0.7 : 1}}>
                                <ShapeComponent />
                            </div>
                         )}
                         {LetterComponent && (
                            <div className="absolute text-white font-bold text-lg xl:text-xl" style={{ textShadow: '0 0 5px black' }}>
                                {LetterComponent}
                            </div>
                        )}
                    </div>
                )
            })}
        </div>
    )
}

const createNewSphere = (id: number, maxPos: number): SphereState => {
    const rawVel = {
        x: (Math.random() - 0.5),
        y: (Math.random() - 0.5),
        z: (Math.random() - 0.5),
    };
    const len = Math.sqrt(rawVel.x ** 2 + rawVel.y ** 2 + rawVel.z ** 2);
    const vel = len > 0 ? { x: rawVel.x / len, y: rawVel.y / len, z: rawVel.z / len } : { x: 1, y: 0, z: 0 };

    return {
        id,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        pos: {
            x: (Math.random() - 0.5) * maxPos * 1.8,
            y: (Math.random() - 0.5) * maxPos * 1.8,
            z: (Math.random() - 0.5) * maxPos * 1.8,
        },
        vel,
        state: 'decorative',
        opacity: 1,
    };
};

const ThreeDSpheresVisualizer: React.FC<VisualizerProps> = ({ stimulus, settings, onVisualStimulusArrival }) => {
  const [spheres, setSpheres] = useState<SphereState[]>([]);
  const [highlightedCell, setHighlightedCell] = useState<{faceIndex: number, cellIndex: number} | null>(null);

  const animationFrameRef = useRef<number | null>(null);
  const nextSphereId = useRef(0);
  const lastFrameTimeRef = useRef<number>(0);
  const activeStimulusId = useRef<number | null>(null);

  const gridSize = settings.gridSize;
  const cellsPerFace = gridSize * gridSize;
  const baseSize = 300;
  const halfSize = baseSize / 2;
  const sphereRadius = baseSize / 24; // Scaled radius
  const impactDisplayTime = 400; // ms

  const { averageTargetSpeed } = useMemo(() => {
    const baseTravelTime = 3000;
    const calculatedTravelTime = Math.max(150, baseTravelTime / settings.sphereSpeed);
    const calculatedAverageTargetSpeed = baseSize / (calculatedTravelTime / 1000);
    return { averageTargetSpeed: calculatedAverageTargetSpeed };
  }, [settings.sphereSpeed, baseSize]);

  useEffect(() => {
    const maxPos = halfSize - sphereRadius;
    setSpheres(currentSpheres => {
        const diff = settings.sphereCount - currentSpheres.filter(s => s.state === 'decorative').length;
        if (diff > 0) {
            const newSpheres = Array.from({ length: diff }).map(() => 
                createNewSphere(nextSphereId.current++, maxPos)
            );
            return [...currentSpheres, ...newSpheres];
        } else if (diff < 0) {
            const decorative = currentSpheres.filter(s => s.state === 'decorative');
            const colliding = currentSpheres.filter(s => s.state !== 'decorative');
            return [...colliding, ...decorative.slice(0, settings.sphereCount)];
        }
        return currentSpheres;
    });
  }, [settings.sphereCount, halfSize, sphereRadius]);

  useEffect(() => {
    if (!stimulus || !stimulus.visual) return;
    if (stimulus.id === activeStimulusId.current) return;
    activeStimulusId.current = stimulus.id;

    setSpheres(prevSpheres => {
        let chosenSphere: SphereState | undefined;
        let nextSpheres = [...prevSpheres];
        const decorativeSpheres = prevSpheres.filter(s => s.state === 'decorative');

        if (decorativeSpheres.length > 0) {
            chosenSphere = decorativeSpheres[0];
        } else {
            const newSphereId = nextSphereId.current++;
            chosenSphere = createNewSphere(newSphereId, halfSize - sphereRadius);
            nextSpheres.push(chosenSphere);
        }
        
        const chosenSphereId = chosenSphere.id;

        let targetStimulusPosition = stimulus.visual!.position;
        const totalPositions = 6 * gridSize * gridSize;

        if (settings.interferenceEnabled && Math.random() < (settings.interferencePercentage / 100)) {
            const originalPosition = targetStimulusPosition;
            do {
                targetStimulusPosition = Math.floor(Math.random() * totalPositions);
            } while (targetStimulusPosition === originalPosition);
        }

        const faceIndex = Math.floor(targetStimulusPosition / cellsPerFace);
        const cellIndexOnFace = targetStimulusPosition % cellsPerFace;
        const col = cellIndexOnFace % gridSize;
        const row = Math.floor(cellIndexOnFace / gridSize);
        const cellSize = baseSize / gridSize;
        const cellOffset = (gridSize - 1) / 2;
        const xOnFace = (col - cellOffset) * cellSize;
        const yOnFace = (row - cellOffset) * cellSize;
        let targetPos = { x: 0, y: 0, z: 0 };
        const boundary = halfSize;
        switch (faceIndex) {
            case 0: targetPos = { x: xOnFace, y: yOnFace, z: boundary }; break; // Front
            case 1: targetPos = { x: -xOnFace, y: yOnFace, z: -boundary }; break; // Back
            case 2: targetPos = { x: boundary, y: yOnFace, z: -xOnFace }; break; // Right
            case 3: targetPos = { x: -boundary, y: yOnFace, z: xOnFace }; break; // Left
            case 4: targetPos = { x: xOnFace, y: -boundary, z: -yOnFace }; break; // Top
            case 5: targetPos = { x: xOnFace, y: boundary, z: yOnFace }; break; // Bottom
        }

        return nextSpheres.map(s => {
            if (s.id === chosenSphereId) {
                const dx = targetPos.x - s.pos.x;
                const dy = targetPos.y - s.pos.y;
                const dz = targetPos.z - s.pos.z;
                const distance = Math.sqrt(dx*dx + dy*dy + dz*dz);
                const calculatedTravelDuration = (distance / averageTargetSpeed) * 1000;

                return {
                    ...s,
                    state: 'colliding',
                    startPos: { ...s.pos },
                    targetPos: targetPos,
                    startTime: performance.now(),
                    travelDuration: calculatedTravelDuration,
                    targetFaceIndex: faceIndex,
                    targetCellIndex: cellIndexOnFace,
                    color: COLORS[stimulus!.visual!.color % COLORS.length],
                    opacity: 1,
                };
            }
            return s;
        });
    });

  }, [stimulus, settings, gridSize, cellsPerFace, baseSize, halfSize, sphereRadius, averageTargetSpeed]);


  useEffect(() => {
    const animate = (time: number) => {
      if (lastFrameTimeRef.current === 0) {
        lastFrameTimeRef.current = time;
        animationFrameRef.current = requestAnimationFrame(animate);
        return;
      }
      const delta = (time - lastFrameTimeRef.current) / 1000.0;
      lastFrameTimeRef.current = time;

      let hasCollidedSphere = false;

      setSpheres(prevSpheres => {
        const newSpheres = prevSpheres.map(s => {
          let newSphere = { ...s };

          if (newSphere.state === 'decorative') {
            const displacement = averageTargetSpeed * delta;
            newSphere.pos = { 
              x: s.pos.x + s.vel.x * displacement, 
              y: s.pos.y + s.vel.y * displacement, 
              z: s.pos.z + s.vel.z * displacement 
            };
            const maxPos = halfSize - sphereRadius;
            if (Math.abs(newSphere.pos.x) > maxPos) { newSphere.vel.x *= -1; newSphere.pos.x = Math.sign(newSphere.pos.x) * maxPos; }
            if (Math.abs(newSphere.pos.y) > maxPos) { newSphere.vel.y *= -1; newSphere.pos.y = Math.sign(newSphere.pos.y) * maxPos; }
            if (Math.abs(newSphere.pos.z) > maxPos) { newSphere.vel.z *= -1; newSphere.pos.z = Math.sign(newSphere.pos.z) * maxPos; }
            return newSphere;
          }

          if (newSphere.state === 'colliding') {
            const elapsedTime = time - newSphere.startTime!;
            const progress = Math.min(elapsedTime / newSphere.travelDuration!, 1);

            newSphere.pos = {
                x: newSphere.startPos!.x + (newSphere.targetPos!.x - newSphere.startPos!.x) * progress,
                y: newSphere.startPos!.y + (newSphere.targetPos!.y - newSphere.startPos!.y) * progress,
                z: newSphere.startPos!.z + (newSphere.targetPos!.z - newSphere.startPos!.z) * progress,
            };

            if (progress >= 1) {
              newSphere.state = 'collided';
              newSphere.collidedTime = time;
              setHighlightedCell({ faceIndex: newSphere.targetFaceIndex!, cellIndex: newSphere.targetCellIndex! });
              onVisualStimulusArrival();
            }
            return newSphere;
          }

          if (newSphere.state === 'collided') {
            hasCollidedSphere = true;
            const elapsedTime = time - newSphere.collidedTime!;
            const fadeProgress = Math.min(elapsedTime / impactDisplayTime, 1);
            newSphere.opacity = 1 - fadeProgress;

            if (elapsedTime >= impactDisplayTime) {
                if (settings.respawnSphere) {
                    return createNewSphere(newSphere.id, halfSize - sphereRadius);
                }
                return null; 
            }
            return newSphere;
          }

          return s;
        }).filter(Boolean) as SphereState[];

        if (!hasCollidedSphere && highlightedCell) {
            setHighlightedCell(null);
        }

        return newSpheres;
      });

      animationFrameRef.current = requestAnimationFrame(animate);
    };

    animationFrameRef.current = requestAnimationFrame(animate);
    return () => { 
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      lastFrameTimeRef.current = 0;
    };
  }, [averageTargetSpeed, halfSize, sphereRadius, onVisualStimulusArrival, settings.respawnSphere, highlightedCell]);

  const activeFaceIndex = highlightedCell?.faceIndex ?? -1;
  const activeCellIndex = highlightedCell?.cellIndex ?? -1;
    
  const faceTransforms = [
    `rotateY(0deg) translateZ(${halfSize}px)`, `rotateY(180deg) translateZ(${halfSize}px)`,
    `rotateY(90deg) translateZ(${halfSize}px)`, `rotateY(-90deg) translateZ(${halfSize}px)`,
    `rotateX(90deg) translateZ(${halfSize}px)`, `rotateX(-90deg) translateZ(${halfSize}px)`,
  ];

  const decorativeSphereSize = baseSize / 25;
  const collidingSphereSize = baseSize / 15;

  return (
    <div className="w-full h-full perspective-container flex items-center justify-center">
      <div 
        className="relative rotating-cube" 
        style={{ 
          width: `${baseSize}px`, height: `${baseSize}px`,
          transformStyle: 'preserve-3d',
          '--camera-angle-x': `${settings.cameraAngleX}deg`
        } as React.CSSProperties}
      >
        {spheres.map(s => (
          <CssSphere
            key={s.id}
            color={s.color}
            size={s.state === 'colliding' || s.state === 'collided' ? collidingSphereSize : decorativeSphereSize}
            style={{ 
              transform: `translate3d(${s.pos.x}px, ${s.pos.y}px, ${s.pos.z}px)`,
              opacity: s.opacity,
              transition: `opacity 0.2s ease, width 0.3s ease, height 0.3s ease`,
            }}
          />
        ))}

        {faceTransforms.map((transform, index) => {
            const activeCellForFace = activeFaceIndex === index ? activeCellIndex : null;
            return (
              <div
                key={`face-${index}`}
                className="absolute border-2 border-blue-300 bg-slate-800/50"
                style={{ transform, width: `${baseSize}px`, height: `${baseSize}px`}}
              >
                 <GridFace 
                    activeCell={activeCellForFace} 
                    gridSize={gridSize}
                    showImpact={activeFaceIndex === index}
                    stimulus={stimulus}
                    settings={settings}
                />
              </div>
            )
        })}
      </div>
    </div>
  );
};

export default ThreeDSpheresVisualizer;