import React from 'react';
import { PerformanceStats, StimulusType } from '../types';

interface PerformanceProps {
  stats: PerformanceStats;
  activeStimuli: StimulusType[];
}

const ACCENT_COLORS: Record<StimulusType, string> = {
    audio: 'bg-blue-100 text-blue-800',
    position: 'bg-green-100 text-green-800',
    color: 'bg-purple-100 text-purple-800',
    shape: 'bg-pink-100 text-pink-800',
    text: 'bg-yellow-100 text-yellow-800',
}
const ACCENT_BG_COLORS: Record<StimulusType, string> = {
    audio: 'bg-blue-500',
    position: 'bg-green-500',
    color: 'bg-purple-500',
    shape: 'bg-pink-500',
    text: 'bg-yellow-500',
}


const Performance: React.FC<PerformanceProps> = ({ stats, activeStimuli }) => {
  const { accuracies, overallAccuracy, scores, bestStreak } = stats;

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Performance</h2>
      <div className="space-y-4">
        {activeStimuli.map(stimulus => {
            const accuracy = accuracies[stimulus] ?? 0;
            return (
                 <div key={stimulus}>
                    <div className="flex justify-between mb-1">
                        <span className={`text-sm font-medium capitalize ${ACCENT_COLORS[stimulus]} px-2 py-0.5 rounded`}>{stimulus} Accuracy</span>
                        <span className={`text-sm font-medium ${ACCENT_COLORS[stimulus]} px-2 py-0.5 rounded`}>{accuracy.toFixed(0)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className={`h-2.5 rounded-full ${ACCENT_BG_COLORS[stimulus]}`} style={{width: `${accuracy}%`}}></div>
                    </div>
                </div>
            )
        })}
       
        <div className="border-t border-gray-200 pt-4">
           <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-orange-800 bg-orange-100 px-2 py-1 rounded">Overall Accuracy</span>
                <span className="text-sm font-medium text-orange-800 bg-orange-100 px-2 py-1 rounded">{overallAccuracy.toFixed(0)}%</span>
            </div>
             <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div className="bg-orange-500 h-2.5 rounded-full" style={{width: `${overallAccuracy}%`}}></div>
            </div>
        </div>

        <div className="border-t border-gray-200 pt-4 grid grid-cols-2 gap-4 text-center">
            <div>
                <p className="text-sm text-gray-500">Scores</p>
                <div className="flex justify-center flex-wrap gap-1 mt-1">
                 {activeStimuli.map(stimulus => (
                    <span key={stimulus} className={`text-xs font-bold px-2 py-0.5 rounded-full ${ACCENT_COLORS[stimulus]}`}>
                        {stimulus.charAt(0).toUpperCase()}: {scores[stimulus]?.correct ?? 0}/{scores[stimulus]?.total ?? 0}
                    </span>
                 ))}
                 </div>
            </div>
             <div>
                <p className="text-sm text-gray-500">Best Streak</p>
                <p className="text-lg font-bold text-yellow-600">{bestStreak}</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Performance;